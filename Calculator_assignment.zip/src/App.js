import './App.css';
import Calculator from './calculator';

function App() {
  return (
    <div className="App">
        <Calculator/>
    </div>
  );
}

export default App;
